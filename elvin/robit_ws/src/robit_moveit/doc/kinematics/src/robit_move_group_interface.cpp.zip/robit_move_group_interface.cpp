#include <iostream>

#include <ros/ros.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>

#include <std_msgs/String.h>
#include <sstream>

#include <unistd.h>

int main(int argc, char **argv) {
	ros::init(argc, argv, "robit_move_group_interface");
	ros::NodeHandle node_handle;
	ros::AsyncSpinner spinner(1);
	spinner.start();

	static const std::string PLANNING_GROUP = "arm";
	const std::string eelink = "tip";


	moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);


	moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

	const robot_state::JointModelGroup *joint_model_group = 
		move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

	const std::vector<std::string> &joint_names = joint_model_group->getVariableNames();


	ROS_INFO_NAMED("tutorial", "Reference frame: %s", move_group.getPlanningFrame().c_str());
	ROS_INFO_NAMED("tutorial", "End effector link: %s", move_group.getEndEffectorLink().c_str());

	std::cout << move_group.getEndEffectorLink().c_str() << '\n';

	moveit::core::RobotStatePtr current_state = move_group.getCurrentState();

	std::vector<double> joint_group_positions;
	current_state->copyJointGroupPositions(joint_model_group, joint_group_positions);

	for (std::size_t i = 0; i < joint_names.size(); ++i) {
		ROS_INFO("Joint %-25s: %f", joint_names[i].c_str(), joint_group_positions[i]);
	}

	geometry_msgs::PoseStamped msg = move_group.getCurrentPose();
	double home_x = msg.pose.position.x;
	double home_y = msg.pose.position.y;
	double home_z = msg.pose.position.z;

	std::cout << home_x << " " << home_y << " " << home_z << '\n';

	// ros::shutdown();
	// return 0;

	ros::Publisher PWM_pub = node_handle.advertise<std_msgs::String>("chatter", 1000);

	/*
	double seq[6][6] = {
		{0, 0, 0, 0.07, 0.15, 0.07},
		{0, 1.57, 0, 0.07, -0.14, -0.14},
		{0, 0, 0, 0, -0.2, 0},
		{0, 0, 0, 0, 0.2, 0},
		{0, 1.57, 0, 0.1, 0, -0.1},
		{0, 0, 0, 0.0000001, 0.0000001, 0.0000001}
	};
	*/
	
	/*
	double seq[3][6] = {
		{0, 0, 0, 0.14, 0, 0},
		{0, 1, 0, 0.14, 0, -0.14},
		{0, 0, 0, 0.00001, 0.0001, 0.0001}
	};
	*/

	double seq[2][6] = {
		{0, 0, 0, 0.15, 0, 0},
		{0, 0, 0, 0.00001, 0.00001, 0.000001}
	};

	// unsigned int sleep = 10000000;
	unsigned int sleep = 1000000;

	while (true) {
	// for (int ii = 0; ii < 2; ii++) {
		double ox, oy, oz, x, y, z;

		std::cin >> ox >> oy >> oz;
		std::cin >> x >> y >> z;

		// ox = seq[ii][0];
		// oy = seq[ii][1];
		// oz = seq[ii][2];
		// x = seq[ii][3];
		// y = seq[ii][4];
		// z = seq[ii][5];

		if (x == -1) {
			break;
		}

		geometry_msgs::Pose target_pose;
		target_pose.orientation.x = ox;
		target_pose.orientation.y = oy;
		target_pose.orientation.z = oz;
		target_pose.orientation.w = 1.0;
		target_pose.position.x = home_x + x;
		target_pose.position.y = home_y + y;
		target_pose.position.z = home_z + z;

		std::cout << "DEBUGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG " << target_pose.position.z << '\n';


		move_group.setJointValueTarget(target_pose);

		moveit::planning_interface::MoveGroupInterface::Plan my_plan;

		move_group.setPlanningTime(20.0);
		move_group.setNumPlanningAttempts(100);

		bool success = false;

		while (!success) (success = move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);

		ROS_INFO_NAMED("tutorial", "Visualizing plan (pose goal) %s", success ? "" : "FAILED");

		// move_group.move();
		// move_group.execute(my_plan);

		std::vector<double> toPush;

		// current_state->copyJointGroupPositions(joint_model_group, joint_group_positions);

		moveit_msgs::RobotTrajectory traj_msg = my_plan.trajectory_;

		std::vector<trajectory_msgs::JointTrajectoryPoint> trajectory_points;
		trajectory_points = traj_msg.joint_trajectory.points;

		std::vector<int>::size_type size = trajectory_points.size();

		// std::cout << "SL:DKGJLDSHGLKJSDHGLKJSHDLKGJHSDLKGHLSKDJHG" << size << '\n';

		// joint_group_positions = move_group.getCurrentJointValues();
		// for (std::size_t i = 0; i < joint_names.size(); ++i) {
		// 	if (i < 4) {
		// 		ROS_INFO("Joint %-25s: %f %f", joint_names[i].c_str(), joint_group_positions[i], joint_group_positions[i]*180/3.1416*750/90);
		// 		toPush.push_back(joint_group_positions[i]*180.0 / 3.1416 * 750.0 / 90.0);
		// 	} else {
		// 		ROS_INFO("Joint %-25s: %f %f", joint_names[i].c_str(), joint_group_positions[i], joint_group_positions[i]*180/3.1416*850/90);
		// 		toPush.push_back(joint_group_positions[i]*180.0 / 3.1416 * 850.0 / 90.0);
		// 	}

		// }

		joint_group_positions.resize(6);

		for (std::size_t i = 0; i < 6; i++) {
			joint_group_positions[i] = traj_msg.joint_trajectory.points[size - 1].positions[i];
		 	if (i < 4) {
				ROS_INFO("Joint %-25s: %f %f", joint_names[i].c_str(), joint_group_positions[i], joint_group_positions[i]*180/3.1416*750/90);
				toPush.push_back(joint_group_positions[i]*180.0 / 3.1416 * 750.0 / 90.0);
			} else {
				ROS_INFO("Joint %-25s: %f %f", joint_names[i].c_str(), joint_group_positions[i], joint_group_positions[i]*180/3.1416*850/90);
				toPush.push_back(joint_group_positions[i]*180.0 / 3.1416 * 850.0 / 90.0);
			}
		}

		toPush[0] += 1350;
		toPush[2] = 650 + (toPush[1] + toPush[2]);
		toPush[1] = 2100 - toPush[1];
		toPush[3] += 1400;
		toPush[4] = 1450 - toPush[4];
		toPush[5] = 1450 - toPush[5];

		std_msgs::String msg;
		std::stringstream ss;

		for (std::size_t i = 0; i < toPush.size(); ++i) {
			ROS_INFO("%f", toPush[i]);
			ss << toPush[i] << ' ';
		}

		std::cout << '\n' << '\n';

		msg.data = ss.str();

		PWM_pub.publish(msg);

		ros::spinOnce();
		move_group.execute(my_plan);

		std::cout << ox << " " << oy << " " << oz << " " << x << " " << y << " " << z << '\n';

		// usleep(sleep);
	}







	// geometry_msgs::Pose target_pose1;
	// target_pose1.orientation.w = 1.0;
	// target_pose1.position.x = home_x + 0.07;
	// target_pose1.position.y = home_y + 0.07;
	// target_pose1.position.z = home_z + 0.07;


	// move_group.setPoseTarget(target_pose1);
	// move_group.setPositionTarget(target_pose1.position.x, target_pose1.position.y, target_pose1.position.z, eelink);
	// move_group.setJointValueTarget(target_pose1);

	// moveit::planning_interface::MoveGroupInterface::Plan my_plan;

	// move_group.setPlanningTime(20.0);

	// move_group.setEndEffectorLink(eelink);

	// ROS_INFO("%s", success ? "SUCCESS" : "FAILED");

	// bool success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);

	// ROS_INFO_NAMED("tutorial", "Visualizing plan 1 (pose goal) %s", success ? "" : "FAILED");

	// move_group.move();

	// std::vector<double> toPush;

	// current_state->copyJointGroupPositions(joint_model_group, joint_group_positions);

	// joint_group_positions = move_group.getCurrentJointValues();
	// for (std::size_t i = 0; i < joint_names.size(); ++i) {
	// 	if (i < 4) {
	// 		ROS_INFO("Joint %-25s: %f %f", joint_names[i].c_str(), joint_group_positions[i], joint_group_positions[i]*180/3.1416*750/90);
	// 		toPush.push_back(joint_group_positions[i]*180.0 / 3.1416 * 750.0 / 90.0);
	// 	} else {
	// 		ROS_INFO("Joint %-25s: %f %f", joint_names[i].c_str(), joint_group_positions[i], joint_group_positions[i]*180/3.1416*850/90);
	// 		toPush.push_back(joint_group_positions[i]*180.0 / 3.1416 * 850.0 / 90.0);
	// 	}

	// }

	// toPush[0] += 1350;
	// toPush[2] = 650 + (toPush[1] + toPush[2]);
	// toPush[1] = 2100 - toPush[1];
	// toPush[3] += 1400;
	// toPush[4] = 1450 - toPush[4];

	// for (std::size_t i = 0; i < toPush.size(); ++i) {
	// 	ROS_INFO("%f", toPush[i]);
	// }

	ros::shutdown();
	return 0;
}
